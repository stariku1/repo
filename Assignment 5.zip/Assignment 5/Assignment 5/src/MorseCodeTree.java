

import java.util.ArrayList;

/**
 * 
 * 
 */
public class MorseCodeTree implements LinkedConverterTreeInterface<String> {

	private TreeNode<String> root;

	/**
	 * 
	 */
	public MorseCodeTree() {
		root = new TreeNode<String>("");
		buildTree();
	}

	/**
	 * calls the buildTree method
	 */
	
	public void addNode(TreeNode<String> root, String code, String letter) {
		if (code.length() == 1) {
			if (code.equals(".")) {
				root.left = new TreeNode<String>(letter);
				return;

			} else if (code.equals("-")) {
				root.right = new TreeNode<String>(letter);
				return;
			}
		} else {
			if (code.charAt(0) == '.') {
				addNode(root.left, code.substring(1), letter);
			} else
				addNode(root.right, code.substring(1), letter);
		}

	}

	/**
	 * root - the root of the tree for this particular recursive instance of addNode
code - the code for this particular recursive instance of addNode
letter - the data of the new TreeNode to be added

	 */
	public MorseCodeTree insert(String code, String letter) {
		addNode(root, code, letter);
		return this;
	}
/**
 * code - the code for the new node to be added, example ".-."
letter - the letter for the corresponding code, example "r"
 */
	public TreeNode<String> getRoot() {
		return root;
	}

	/**
	 * the MorseCodeTree with the new node added
	 */
	public void setRoot(TreeNode<String> newNode) {
		root = newNode;
	}

	/**
	 *
	 * 
	 * @param
	 * @return
	 */
	public String fetch(String code) {
		return fetchNode(root, code);
	}

	/**
	 * 
	 * 
	 * @param
	 * @param
	 * @return
	 */
	public String fetchNode(TreeNode<String> root, String code) {
		if (code.length() == 1) {
			if (code.equals(".")) {
				return root.left.getData();
			} else if (code.equals("-")) {
				return root.right.getData();
			}
		} else {
			if (code.charAt(0) == '.') {
				return fetchNode(root.left, code.substring(1));

			} else {
				return fetchNode(root.right, code.substring(1));

			}
		}
		return null;
	}

	
	public LinkedConverterTreeInterface<String> delete(String data) throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	
	public LinkedConverterTreeInterface<String> update() throws UnsupportedOperationException {
		throw new UnsupportedOperationException();
	}

	
	public void buildTree() {
		setRoot(new TreeNode<String>(""));// root level 0
		insert(".", "e");
		insert("-", "t");// level 1
		insert("..", "i");
		insert(".-", "a");
		insert("-.", "n");
		insert("--", "m");// level 2
		insert("...", "s");
		insert("..-", "u");
		insert(".-.", "r");
		insert(".--", "w");// level 3 left
		insert("-..", "d");
		insert("-.-", "k");
		insert("--.", "g");
		insert("---", "o"); // two null nodes level 3 right
		insert("....", "h");
		insert("...-", "v");
		insert("..-.", "f");
		/* null node */ insert(".-..", "l");
		/* null */ insert(".--.", "p");
		insert(".---", "j"); // level 4 left
		insert("-...", "b");
		insert("-..-", "x");
		insert("-.-.", "c");
		insert("-.--", "y");
		insert("--..", "z");
		insert("--.-", "q");// level 4 right

	}

	/**
	 * @return an ArrayList of the items in the linked Tree
	 */
	public ArrayList<String> toArrayList() {
		ArrayList<String> list = new ArrayList<String>();
		TreeNode<String> root = getRoot();
		LNRoutputTraversal(root, list);
		return list;
	}

	/**
	 * root the root of the tree for this particular recursive instance
	 * list the ArrayList that will hold the contents of the tree in LNR
	 *             order
	 */
	public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
		if (root == null) {
			return;
		}
		LNRoutputTraversal(root.left, list);
		list.add(root.getData());
		LNRoutputTraversal(root.right, list);
	}
}