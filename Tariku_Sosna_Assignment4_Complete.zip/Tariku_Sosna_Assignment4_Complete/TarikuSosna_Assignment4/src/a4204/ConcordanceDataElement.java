package a4204;

import java.util.LinkedList;

/**
 * 
 * @author sosna
 */
public class ConcordanceDataElement implements Comparable<ConcordanceDataElement> {

    /**
     * consists of a String (the word) and a reference to a LinkedList
     */
    private String word;
    
    /**
     * string used to find the word
     */
    private LinkedList<Integer> linkedList;
    
    /**
     *  
     * element with a word and no pages
     * @param word word in text or file
     */
    public ConcordanceDataElement(String word) {
        this.word = word;
        linkedList = new LinkedList<>();
    }
    
    /**
     * 
     * @return the word followed by page numbers Returns a string in the following format: word: page num, page num Example: after: 2,8,15
     */
    public String getWord() {
        return word;
    }
    
    /**
     * 
     * @return the word portion of the Concordance Data Element
     */
    public LinkedList<Integer> getList() {
        return linkedList;
    }
    
    /**
     * 
     * @param num to find word
     */
    public void addPage(int num) {
        if (!linkedList.contains(num)) {
        	linkedList.add(num);
        }
    }
    
    /**
     * 
     * @return the linked list of integers that represent the numbers
     */
    @Override
    public String toString() {
        String concordance = word + "- ";
        for (int a = 0; a < linkedList.size(); a++) {
            concordance += (a == 0 ? linkedList.get(a) : "-" + linkedList.get(a));
        }
        return concordance;
    }
    
    /**
     * 
     * @param element another concordance element
     * @return 
     */
    @Override
    public int compareTo(ConcordanceDataElement element) {        
        throw new UnsupportedOperationException();
    }
    
    /**
     * 
     * @return hashCode in class java.lang.Object

     */
    @Override
    public int hashCode() {
        return word.hashCode();
    }
}
