
public class TreeNode<T> {

	private T data;
	TreeNode<T> left;
	TreeNode<T> right;
	
	/**
	 * 
	 * @param dataNode the data to be stored in the TreeNode
	 */
	
	public TreeNode (T dataNode) {
		left=null;
		right= null;
		data= dataNode;
		
		
		
	}
	
	/**
	 * 
	 * @param node node to make copy of
	 */
	public TreeNode(TreeNode<T> node){
		data = node.data;
		left = node.left;
		right = node.right;
	}
	
	/**
	 * 
	 * @returnthe data within the TreeNode
	 */
	
	public T getData() {
		return data;
		
	}
	
}
