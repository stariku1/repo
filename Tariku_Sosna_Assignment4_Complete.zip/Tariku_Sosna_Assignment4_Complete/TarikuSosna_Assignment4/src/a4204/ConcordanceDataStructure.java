package a4204;



import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

/**
 * 
 * @author sosna
 */
public class ConcordanceDataStructure implements ConcordanceDataStructureInterface {
    
    private LinkedList<ConcordanceDataElement>[] concordanceTable;

    /**
     * This constructor takes in an integer which represents the estimated number of words in the text.
     * 
     * @param the estimated number of words in the text
     */
    ConcordanceDataStructure(int number) {
        boolean fprime = false;
        boolean notprime = false;
        int p, hd, b;
        p = (int)(number / 1.5);
        
        if(p % 2 == 0) 
            p = p +1;
        while(fprime == false) { 
            while(notprime == false) { 
                hd = (int)(Math.sqrt(p) + 0.5);
                for(b = hd; b > 1; b--) {  
                    if(p % b == 0)
                        break; 
	        }
	        if(b != 1) 
                    p = p + 2;
                else
                    notprime = true;
	    } 
            if((p - 3) % 4 == 0)
                fprime = true;
            else {  
                p = p + 2;
                notprime = false;
            }
        }
        
        concordanceTable = new LinkedList[p];
        for (int a = 0; a < concordanceTable.length; a++){
            concordanceTable[a] = new LinkedList<>();
        }
    }

    /**
     * This constructor is responsible for using the concordance
     * data structure class for testing purposes
     * @param testing testing purposes label
     * @param size size of the concordance table
     */
    ConcordanceDataStructure(String testing, int size) {
        concordanceTable = new LinkedList[size];
        for (int i = 0; i < concordanceTable.length; i++){
            concordanceTable[i] = new LinkedList<>();
        }
    }

    @Override
    public int getTableSize() {
        return concordanceTable.length;
    }

    @Override
    public ArrayList<String> getWords(int index) {
        ArrayList<String> wordList = new ArrayList<>();
        for (ConcordanceDataElement e : concordanceTable[index]) {
            wordList.add(e.getWord());
        }
        return wordList;
    }

    @Override
    public ArrayList<LinkedList<Integer>> getPageNumbers(int index) {
        ArrayList<LinkedList<Integer>> pageNumbers = new ArrayList<>();
        for (ConcordanceDataElement e : concordanceTable[index]) {
            pageNumbers.add(e.getList());
        }
        return pageNumbers;
    }

    @Override
    public void add(String word, int lineNum) {
        ConcordanceDataElement element = new ConcordanceDataElement(word);
        int hashIdx = Math.abs(element.hashCode() % concordanceTable.length), idx;
        boolean contains = false;
        for (idx = 0; idx < concordanceTable[hashIdx].size(); idx++) {
            if (concordanceTable[hashIdx].get(idx)
                    .getWord().equalsIgnoreCase(word)) {
                contains = true;
                break;
            }   
        }
        
        if (contains) {
            concordanceTable[hashIdx].get(idx).addPage(lineNum);
        } else {
            element.addPage(lineNum);
            concordanceTable[hashIdx].add(element);
        }
        
    }

    @Override
    public ArrayList<String> showAll() {
        ArrayList<String> concordanceList = new ArrayList<>();
        for (LinkedList<ConcordanceDataElement> list : concordanceTable) {
            for (ConcordanceDataElement e : list) {
                concordanceList.add(e.toString());
            }
        }
        Collections.sort(concordanceList);
        for (int i = 0; i < concordanceList.size(); i++) {
            if (concordanceList.get(i).contains("'")) {
                String temp = concordanceList.get(i);
                concordanceList.set(i, concordanceList.get(i + 1));
                concordanceList.set(i + 1, temp);
                i++;
            }
        }
        return concordanceList;
    }
}

