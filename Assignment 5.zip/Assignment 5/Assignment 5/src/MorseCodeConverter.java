

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * converts morse Code from a string or file
 * 
 *
 */
public class MorseCodeConverter {
	private static MorseCodeTree tree = new MorseCodeTree();

	/**
	 * 
	 * @return output 
	 */
	public static String printTree() {
		ArrayList<String> list = tree.toArrayList();
		String lnr = "";
		for (int i = 0; i < list.size(); i++) {
			if (i == list.size() - 1) {
				lnr += list.get(i);
			} else
				lnr += list.get(i) + " ";
		}
		return lnr;
	}

	/**
	 *the data in the tree in LNR order separated by a space.
	 *
	 */
	public static String convertToEnglish(String morseCode) {
		Scanner sc = new Scanner(morseCode);
		sc.useDelimiter("/");

		String word, returned = "";
		while (sc.hasNext()) {
			word = sc.next();
			Scanner a = new Scanner(word);
			a.useDelimiter(" ");

			String letter;
			while (a.hasNext()) {
				letter = a.next();
				letter = tree.fetch(letter);
				returned += letter;
			}

			if (sc.hasNext() != false) {
				returned += " ";
			}
		}

		return returned;
	}

	/**
	 * 
	 * @param codeFile - name of the File that contains Morse Code
	 * @return the English translation of the file
	 * @throws java.io.FileNotFoundException
	 */
	public static String convertToEnglish(File codeFile) throws java.io.FileNotFoundException {
		Scanner sc;
		String returned = "";
		try {
			sc = new Scanner(codeFile);
			while (sc.hasNextLine()) {
				String line = convertToEnglish(sc.nextLine());
				if (sc.hasNextLine()) {
					returned += line + " ";
				} else
					returned += line;
			}

		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
		return returned;
	}
}